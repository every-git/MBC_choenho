ls -l 1> /home/ubuntu/cron.log
